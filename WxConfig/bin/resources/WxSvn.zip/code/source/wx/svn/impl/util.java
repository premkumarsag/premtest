package wx.svn.impl;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2014-01-26 18:28:34 GMT
// -----( ON-HOST: LDV00208.catlin.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import com.wm.app.b2b.server.InvokeState;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataUtil;
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void executeOSCommand (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(executeOSCommand)>> ---
		// @sigtype java 3.5
		// [i] field:0:required command
		// [o] object:1:required commandOutput
		// [o] field:0:required commandOutputSize
		// [o] object:1:required commandError
		// [o] field:0:required commandErrorSize
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	command = IDataUtil.getString( pipelineCursor, "command" );
		pipelineCursor.destroy(); 
		
		ArrayList<String> aO = new ArrayList<String>();
		ArrayList<String> aE = new ArrayList<String>();
		
		try{
			Process process = Runtime.getRuntime().exec(command);
			process.waitFor();
		
			// Get input streams
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(
					process.getInputStream()));
			BufferedReader stdError = new BufferedReader(new InputStreamReader(
					process.getErrorStream()));
		
			// Read command standard output
			String s;
			while ((s = stdInput.readLine()) != null) {
			     aO.add(s);
			}
			
		
			// Read command errors
			String commandError;
			while ((s = stdError.readLine()) != null) {
			    aE.add(s);
			}
		 
		}catch(Exception ee){ 
			throw new ServiceException (ee.getMessage());
		} 
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		Object[] commandOutput = aO.toArray();
		IDataUtil.put( pipelineCursor_1, "commandOutput", commandOutput );
		IDataUtil.put( pipelineCursor_1, "commandOutputSize", String.valueOf(commandOutput.length));
		
		Object[] commandError =  aE.toArray();
		IDataUtil.put( pipelineCursor_1, "commandError", commandError );
		IDataUtil.put( pipelineCursor_1, "commandErrorSize", String.valueOf(commandError.length));
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getCurrentUser (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getCurrentUser)>> ---
		// @sigtype java 3.5
		// [o] field:0:required userName
		// pipeline
		InvokeState is = new InvokeState(); 
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "userName", is.getCurrentUser().getName());
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}
}

